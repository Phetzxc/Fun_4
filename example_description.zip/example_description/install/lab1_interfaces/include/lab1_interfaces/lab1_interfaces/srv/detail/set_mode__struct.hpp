// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from lab1_interfaces:srv/SetMode.idl
// generated code does not contain a copyright notice

#ifndef LAB1_INTERFACES__SRV__DETAIL__SET_MODE__STRUCT_HPP_
#define LAB1_INTERFACES__SRV__DETAIL__SET_MODE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'mode'
// Member 'newtarget'
#include "std_msgs/msg/detail/u_int8__struct.hpp"
// Member 'x'
// Member 'y'
// Member 'z'
#include "std_msgs/msg/detail/float64__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__lab1_interfaces__srv__SetMode_Request __attribute__((deprecated))
#else
# define DEPRECATED__lab1_interfaces__srv__SetMode_Request __declspec(deprecated)
#endif

namespace lab1_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetMode_Request_
{
  using Type = SetMode_Request_<ContainerAllocator>;

  explicit SetMode_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : mode(_init),
    x(_init),
    y(_init),
    z(_init),
    newtarget(_init)
  {
    (void)_init;
  }

  explicit SetMode_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : mode(_alloc, _init),
    x(_alloc, _init),
    y(_alloc, _init),
    z(_alloc, _init),
    newtarget(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _mode_type =
    std_msgs::msg::UInt8_<ContainerAllocator>;
  _mode_type mode;
  using _x_type =
    std_msgs::msg::Float64_<ContainerAllocator>;
  _x_type x;
  using _y_type =
    std_msgs::msg::Float64_<ContainerAllocator>;
  _y_type y;
  using _z_type =
    std_msgs::msg::Float64_<ContainerAllocator>;
  _z_type z;
  using _newtarget_type =
    std_msgs::msg::UInt8_<ContainerAllocator>;
  _newtarget_type newtarget;

  // setters for named parameter idiom
  Type & set__mode(
    const std_msgs::msg::UInt8_<ContainerAllocator> & _arg)
  {
    this->mode = _arg;
    return *this;
  }
  Type & set__x(
    const std_msgs::msg::Float64_<ContainerAllocator> & _arg)
  {
    this->x = _arg;
    return *this;
  }
  Type & set__y(
    const std_msgs::msg::Float64_<ContainerAllocator> & _arg)
  {
    this->y = _arg;
    return *this;
  }
  Type & set__z(
    const std_msgs::msg::Float64_<ContainerAllocator> & _arg)
  {
    this->z = _arg;
    return *this;
  }
  Type & set__newtarget(
    const std_msgs::msg::UInt8_<ContainerAllocator> & _arg)
  {
    this->newtarget = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    lab1_interfaces::srv::SetMode_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const lab1_interfaces::srv::SetMode_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<lab1_interfaces::srv::SetMode_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<lab1_interfaces::srv::SetMode_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      lab1_interfaces::srv::SetMode_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<lab1_interfaces::srv::SetMode_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      lab1_interfaces::srv::SetMode_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<lab1_interfaces::srv::SetMode_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<lab1_interfaces::srv::SetMode_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<lab1_interfaces::srv::SetMode_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__lab1_interfaces__srv__SetMode_Request
    std::shared_ptr<lab1_interfaces::srv::SetMode_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__lab1_interfaces__srv__SetMode_Request
    std::shared_ptr<lab1_interfaces::srv::SetMode_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetMode_Request_ & other) const
  {
    if (this->mode != other.mode) {
      return false;
    }
    if (this->x != other.x) {
      return false;
    }
    if (this->y != other.y) {
      return false;
    }
    if (this->z != other.z) {
      return false;
    }
    if (this->newtarget != other.newtarget) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetMode_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetMode_Request_

// alias to use template instance with default allocator
using SetMode_Request =
  lab1_interfaces::srv::SetMode_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace lab1_interfaces


// Include directives for member types
// Member 'result'
// Member 'ipk'
// already included above
// #include "std_msgs/msg/detail/u_int8__struct.hpp"
// Member 'q0sol'
// Member 'q1sol'
// Member 'q2sol'
// Member 'ranx'
// Member 'rany'
// Member 'ranz'
// already included above
// #include "std_msgs/msg/detail/float64__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__lab1_interfaces__srv__SetMode_Response __attribute__((deprecated))
#else
# define DEPRECATED__lab1_interfaces__srv__SetMode_Response __declspec(deprecated)
#endif

namespace lab1_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetMode_Response_
{
  using Type = SetMode_Response_<ContainerAllocator>;

  explicit SetMode_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : result(_init),
    ipk(_init),
    q0sol(_init),
    q1sol(_init),
    q2sol(_init),
    ranx(_init),
    rany(_init),
    ranz(_init)
  {
    (void)_init;
  }

  explicit SetMode_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : result(_alloc, _init),
    ipk(_alloc, _init),
    q0sol(_alloc, _init),
    q1sol(_alloc, _init),
    q2sol(_alloc, _init),
    ranx(_alloc, _init),
    rany(_alloc, _init),
    ranz(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _result_type =
    std_msgs::msg::UInt8_<ContainerAllocator>;
  _result_type result;
  using _ipk_type =
    std_msgs::msg::UInt8_<ContainerAllocator>;
  _ipk_type ipk;
  using _q0sol_type =
    std_msgs::msg::Float64_<ContainerAllocator>;
  _q0sol_type q0sol;
  using _q1sol_type =
    std_msgs::msg::Float64_<ContainerAllocator>;
  _q1sol_type q1sol;
  using _q2sol_type =
    std_msgs::msg::Float64_<ContainerAllocator>;
  _q2sol_type q2sol;
  using _ranx_type =
    std_msgs::msg::Float64_<ContainerAllocator>;
  _ranx_type ranx;
  using _rany_type =
    std_msgs::msg::Float64_<ContainerAllocator>;
  _rany_type rany;
  using _ranz_type =
    std_msgs::msg::Float64_<ContainerAllocator>;
  _ranz_type ranz;

  // setters for named parameter idiom
  Type & set__result(
    const std_msgs::msg::UInt8_<ContainerAllocator> & _arg)
  {
    this->result = _arg;
    return *this;
  }
  Type & set__ipk(
    const std_msgs::msg::UInt8_<ContainerAllocator> & _arg)
  {
    this->ipk = _arg;
    return *this;
  }
  Type & set__q0sol(
    const std_msgs::msg::Float64_<ContainerAllocator> & _arg)
  {
    this->q0sol = _arg;
    return *this;
  }
  Type & set__q1sol(
    const std_msgs::msg::Float64_<ContainerAllocator> & _arg)
  {
    this->q1sol = _arg;
    return *this;
  }
  Type & set__q2sol(
    const std_msgs::msg::Float64_<ContainerAllocator> & _arg)
  {
    this->q2sol = _arg;
    return *this;
  }
  Type & set__ranx(
    const std_msgs::msg::Float64_<ContainerAllocator> & _arg)
  {
    this->ranx = _arg;
    return *this;
  }
  Type & set__rany(
    const std_msgs::msg::Float64_<ContainerAllocator> & _arg)
  {
    this->rany = _arg;
    return *this;
  }
  Type & set__ranz(
    const std_msgs::msg::Float64_<ContainerAllocator> & _arg)
  {
    this->ranz = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    lab1_interfaces::srv::SetMode_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const lab1_interfaces::srv::SetMode_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<lab1_interfaces::srv::SetMode_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<lab1_interfaces::srv::SetMode_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      lab1_interfaces::srv::SetMode_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<lab1_interfaces::srv::SetMode_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      lab1_interfaces::srv::SetMode_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<lab1_interfaces::srv::SetMode_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<lab1_interfaces::srv::SetMode_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<lab1_interfaces::srv::SetMode_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__lab1_interfaces__srv__SetMode_Response
    std::shared_ptr<lab1_interfaces::srv::SetMode_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__lab1_interfaces__srv__SetMode_Response
    std::shared_ptr<lab1_interfaces::srv::SetMode_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetMode_Response_ & other) const
  {
    if (this->result != other.result) {
      return false;
    }
    if (this->ipk != other.ipk) {
      return false;
    }
    if (this->q0sol != other.q0sol) {
      return false;
    }
    if (this->q1sol != other.q1sol) {
      return false;
    }
    if (this->q2sol != other.q2sol) {
      return false;
    }
    if (this->ranx != other.ranx) {
      return false;
    }
    if (this->rany != other.rany) {
      return false;
    }
    if (this->ranz != other.ranz) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetMode_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetMode_Response_

// alias to use template instance with default allocator
using SetMode_Response =
  lab1_interfaces::srv::SetMode_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace lab1_interfaces

namespace lab1_interfaces
{

namespace srv
{

struct SetMode
{
  using Request = lab1_interfaces::srv::SetMode_Request;
  using Response = lab1_interfaces::srv::SetMode_Response;
};

}  // namespace srv

}  // namespace lab1_interfaces

#endif  // LAB1_INTERFACES__SRV__DETAIL__SET_MODE__STRUCT_HPP_
