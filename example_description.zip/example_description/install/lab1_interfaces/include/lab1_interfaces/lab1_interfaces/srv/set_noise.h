// generated from rosidl_generator_c/resource/idl.h.em
// with input from lab1_interfaces:srv/SetNoise.idl
// generated code does not contain a copyright notice

#ifndef LAB1_INTERFACES__SRV__SET_NOISE_H_
#define LAB1_INTERFACES__SRV__SET_NOISE_H_

#include "lab1_interfaces/srv/detail/set_noise__struct.h"
#include "lab1_interfaces/srv/detail/set_noise__functions.h"
#include "lab1_interfaces/srv/detail/set_noise__type_support.h"

#endif  // LAB1_INTERFACES__SRV__SET_NOISE_H_
