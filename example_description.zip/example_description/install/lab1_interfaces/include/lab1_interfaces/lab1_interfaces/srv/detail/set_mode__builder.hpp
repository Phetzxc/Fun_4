// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from lab1_interfaces:srv/SetMode.idl
// generated code does not contain a copyright notice

#ifndef LAB1_INTERFACES__SRV__DETAIL__SET_MODE__BUILDER_HPP_
#define LAB1_INTERFACES__SRV__DETAIL__SET_MODE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "lab1_interfaces/srv/detail/set_mode__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace lab1_interfaces
{

namespace srv
{

namespace builder
{

class Init_SetMode_Request_newtarget
{
public:
  explicit Init_SetMode_Request_newtarget(::lab1_interfaces::srv::SetMode_Request & msg)
  : msg_(msg)
  {}
  ::lab1_interfaces::srv::SetMode_Request newtarget(::lab1_interfaces::srv::SetMode_Request::_newtarget_type arg)
  {
    msg_.newtarget = std::move(arg);
    return std::move(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Request msg_;
};

class Init_SetMode_Request_z
{
public:
  explicit Init_SetMode_Request_z(::lab1_interfaces::srv::SetMode_Request & msg)
  : msg_(msg)
  {}
  Init_SetMode_Request_newtarget z(::lab1_interfaces::srv::SetMode_Request::_z_type arg)
  {
    msg_.z = std::move(arg);
    return Init_SetMode_Request_newtarget(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Request msg_;
};

class Init_SetMode_Request_y
{
public:
  explicit Init_SetMode_Request_y(::lab1_interfaces::srv::SetMode_Request & msg)
  : msg_(msg)
  {}
  Init_SetMode_Request_z y(::lab1_interfaces::srv::SetMode_Request::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_SetMode_Request_z(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Request msg_;
};

class Init_SetMode_Request_x
{
public:
  explicit Init_SetMode_Request_x(::lab1_interfaces::srv::SetMode_Request & msg)
  : msg_(msg)
  {}
  Init_SetMode_Request_y x(::lab1_interfaces::srv::SetMode_Request::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_SetMode_Request_y(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Request msg_;
};

class Init_SetMode_Request_mode
{
public:
  Init_SetMode_Request_mode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetMode_Request_x mode(::lab1_interfaces::srv::SetMode_Request::_mode_type arg)
  {
    msg_.mode = std::move(arg);
    return Init_SetMode_Request_x(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::lab1_interfaces::srv::SetMode_Request>()
{
  return lab1_interfaces::srv::builder::Init_SetMode_Request_mode();
}

}  // namespace lab1_interfaces


namespace lab1_interfaces
{

namespace srv
{

namespace builder
{

class Init_SetMode_Response_ranz
{
public:
  explicit Init_SetMode_Response_ranz(::lab1_interfaces::srv::SetMode_Response & msg)
  : msg_(msg)
  {}
  ::lab1_interfaces::srv::SetMode_Response ranz(::lab1_interfaces::srv::SetMode_Response::_ranz_type arg)
  {
    msg_.ranz = std::move(arg);
    return std::move(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Response msg_;
};

class Init_SetMode_Response_rany
{
public:
  explicit Init_SetMode_Response_rany(::lab1_interfaces::srv::SetMode_Response & msg)
  : msg_(msg)
  {}
  Init_SetMode_Response_ranz rany(::lab1_interfaces::srv::SetMode_Response::_rany_type arg)
  {
    msg_.rany = std::move(arg);
    return Init_SetMode_Response_ranz(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Response msg_;
};

class Init_SetMode_Response_ranx
{
public:
  explicit Init_SetMode_Response_ranx(::lab1_interfaces::srv::SetMode_Response & msg)
  : msg_(msg)
  {}
  Init_SetMode_Response_rany ranx(::lab1_interfaces::srv::SetMode_Response::_ranx_type arg)
  {
    msg_.ranx = std::move(arg);
    return Init_SetMode_Response_rany(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Response msg_;
};

class Init_SetMode_Response_q2sol
{
public:
  explicit Init_SetMode_Response_q2sol(::lab1_interfaces::srv::SetMode_Response & msg)
  : msg_(msg)
  {}
  Init_SetMode_Response_ranx q2sol(::lab1_interfaces::srv::SetMode_Response::_q2sol_type arg)
  {
    msg_.q2sol = std::move(arg);
    return Init_SetMode_Response_ranx(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Response msg_;
};

class Init_SetMode_Response_q1sol
{
public:
  explicit Init_SetMode_Response_q1sol(::lab1_interfaces::srv::SetMode_Response & msg)
  : msg_(msg)
  {}
  Init_SetMode_Response_q2sol q1sol(::lab1_interfaces::srv::SetMode_Response::_q1sol_type arg)
  {
    msg_.q1sol = std::move(arg);
    return Init_SetMode_Response_q2sol(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Response msg_;
};

class Init_SetMode_Response_q0sol
{
public:
  explicit Init_SetMode_Response_q0sol(::lab1_interfaces::srv::SetMode_Response & msg)
  : msg_(msg)
  {}
  Init_SetMode_Response_q1sol q0sol(::lab1_interfaces::srv::SetMode_Response::_q0sol_type arg)
  {
    msg_.q0sol = std::move(arg);
    return Init_SetMode_Response_q1sol(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Response msg_;
};

class Init_SetMode_Response_ipk
{
public:
  explicit Init_SetMode_Response_ipk(::lab1_interfaces::srv::SetMode_Response & msg)
  : msg_(msg)
  {}
  Init_SetMode_Response_q0sol ipk(::lab1_interfaces::srv::SetMode_Response::_ipk_type arg)
  {
    msg_.ipk = std::move(arg);
    return Init_SetMode_Response_q0sol(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Response msg_;
};

class Init_SetMode_Response_result
{
public:
  Init_SetMode_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetMode_Response_ipk result(::lab1_interfaces::srv::SetMode_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_SetMode_Response_ipk(msg_);
  }

private:
  ::lab1_interfaces::srv::SetMode_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::lab1_interfaces::srv::SetMode_Response>()
{
  return lab1_interfaces::srv::builder::Init_SetMode_Response_result();
}

}  // namespace lab1_interfaces

#endif  // LAB1_INTERFACES__SRV__DETAIL__SET_MODE__BUILDER_HPP_
