// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from lab1_interfaces:srv/SetMode.idl
// generated code does not contain a copyright notice
#include "lab1_interfaces/srv/detail/set_mode__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `mode`
// Member `newtarget`
#include "std_msgs/msg/detail/u_int8__functions.h"
// Member `x`
// Member `y`
// Member `z`
#include "std_msgs/msg/detail/float64__functions.h"

bool
lab1_interfaces__srv__SetMode_Request__init(lab1_interfaces__srv__SetMode_Request * msg)
{
  if (!msg) {
    return false;
  }
  // mode
  if (!std_msgs__msg__UInt8__init(&msg->mode)) {
    lab1_interfaces__srv__SetMode_Request__fini(msg);
    return false;
  }
  // x
  if (!std_msgs__msg__Float64__init(&msg->x)) {
    lab1_interfaces__srv__SetMode_Request__fini(msg);
    return false;
  }
  // y
  if (!std_msgs__msg__Float64__init(&msg->y)) {
    lab1_interfaces__srv__SetMode_Request__fini(msg);
    return false;
  }
  // z
  if (!std_msgs__msg__Float64__init(&msg->z)) {
    lab1_interfaces__srv__SetMode_Request__fini(msg);
    return false;
  }
  // newtarget
  if (!std_msgs__msg__UInt8__init(&msg->newtarget)) {
    lab1_interfaces__srv__SetMode_Request__fini(msg);
    return false;
  }
  return true;
}

void
lab1_interfaces__srv__SetMode_Request__fini(lab1_interfaces__srv__SetMode_Request * msg)
{
  if (!msg) {
    return;
  }
  // mode
  std_msgs__msg__UInt8__fini(&msg->mode);
  // x
  std_msgs__msg__Float64__fini(&msg->x);
  // y
  std_msgs__msg__Float64__fini(&msg->y);
  // z
  std_msgs__msg__Float64__fini(&msg->z);
  // newtarget
  std_msgs__msg__UInt8__fini(&msg->newtarget);
}

bool
lab1_interfaces__srv__SetMode_Request__are_equal(const lab1_interfaces__srv__SetMode_Request * lhs, const lab1_interfaces__srv__SetMode_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // mode
  if (!std_msgs__msg__UInt8__are_equal(
      &(lhs->mode), &(rhs->mode)))
  {
    return false;
  }
  // x
  if (!std_msgs__msg__Float64__are_equal(
      &(lhs->x), &(rhs->x)))
  {
    return false;
  }
  // y
  if (!std_msgs__msg__Float64__are_equal(
      &(lhs->y), &(rhs->y)))
  {
    return false;
  }
  // z
  if (!std_msgs__msg__Float64__are_equal(
      &(lhs->z), &(rhs->z)))
  {
    return false;
  }
  // newtarget
  if (!std_msgs__msg__UInt8__are_equal(
      &(lhs->newtarget), &(rhs->newtarget)))
  {
    return false;
  }
  return true;
}

bool
lab1_interfaces__srv__SetMode_Request__copy(
  const lab1_interfaces__srv__SetMode_Request * input,
  lab1_interfaces__srv__SetMode_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // mode
  if (!std_msgs__msg__UInt8__copy(
      &(input->mode), &(output->mode)))
  {
    return false;
  }
  // x
  if (!std_msgs__msg__Float64__copy(
      &(input->x), &(output->x)))
  {
    return false;
  }
  // y
  if (!std_msgs__msg__Float64__copy(
      &(input->y), &(output->y)))
  {
    return false;
  }
  // z
  if (!std_msgs__msg__Float64__copy(
      &(input->z), &(output->z)))
  {
    return false;
  }
  // newtarget
  if (!std_msgs__msg__UInt8__copy(
      &(input->newtarget), &(output->newtarget)))
  {
    return false;
  }
  return true;
}

lab1_interfaces__srv__SetMode_Request *
lab1_interfaces__srv__SetMode_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  lab1_interfaces__srv__SetMode_Request * msg = (lab1_interfaces__srv__SetMode_Request *)allocator.allocate(sizeof(lab1_interfaces__srv__SetMode_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(lab1_interfaces__srv__SetMode_Request));
  bool success = lab1_interfaces__srv__SetMode_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
lab1_interfaces__srv__SetMode_Request__destroy(lab1_interfaces__srv__SetMode_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    lab1_interfaces__srv__SetMode_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
lab1_interfaces__srv__SetMode_Request__Sequence__init(lab1_interfaces__srv__SetMode_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  lab1_interfaces__srv__SetMode_Request * data = NULL;

  if (size) {
    data = (lab1_interfaces__srv__SetMode_Request *)allocator.zero_allocate(size, sizeof(lab1_interfaces__srv__SetMode_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = lab1_interfaces__srv__SetMode_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        lab1_interfaces__srv__SetMode_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
lab1_interfaces__srv__SetMode_Request__Sequence__fini(lab1_interfaces__srv__SetMode_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      lab1_interfaces__srv__SetMode_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

lab1_interfaces__srv__SetMode_Request__Sequence *
lab1_interfaces__srv__SetMode_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  lab1_interfaces__srv__SetMode_Request__Sequence * array = (lab1_interfaces__srv__SetMode_Request__Sequence *)allocator.allocate(sizeof(lab1_interfaces__srv__SetMode_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = lab1_interfaces__srv__SetMode_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
lab1_interfaces__srv__SetMode_Request__Sequence__destroy(lab1_interfaces__srv__SetMode_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    lab1_interfaces__srv__SetMode_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
lab1_interfaces__srv__SetMode_Request__Sequence__are_equal(const lab1_interfaces__srv__SetMode_Request__Sequence * lhs, const lab1_interfaces__srv__SetMode_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!lab1_interfaces__srv__SetMode_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
lab1_interfaces__srv__SetMode_Request__Sequence__copy(
  const lab1_interfaces__srv__SetMode_Request__Sequence * input,
  lab1_interfaces__srv__SetMode_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(lab1_interfaces__srv__SetMode_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    lab1_interfaces__srv__SetMode_Request * data =
      (lab1_interfaces__srv__SetMode_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!lab1_interfaces__srv__SetMode_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          lab1_interfaces__srv__SetMode_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!lab1_interfaces__srv__SetMode_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `result`
// Member `ipk`
// already included above
// #include "std_msgs/msg/detail/u_int8__functions.h"
// Member `q0sol`
// Member `q1sol`
// Member `q2sol`
// Member `ranx`
// Member `rany`
// Member `ranz`
// already included above
// #include "std_msgs/msg/detail/float64__functions.h"

bool
lab1_interfaces__srv__SetMode_Response__init(lab1_interfaces__srv__SetMode_Response * msg)
{
  if (!msg) {
    return false;
  }
  // result
  if (!std_msgs__msg__UInt8__init(&msg->result)) {
    lab1_interfaces__srv__SetMode_Response__fini(msg);
    return false;
  }
  // ipk
  if (!std_msgs__msg__UInt8__init(&msg->ipk)) {
    lab1_interfaces__srv__SetMode_Response__fini(msg);
    return false;
  }
  // q0sol
  if (!std_msgs__msg__Float64__init(&msg->q0sol)) {
    lab1_interfaces__srv__SetMode_Response__fini(msg);
    return false;
  }
  // q1sol
  if (!std_msgs__msg__Float64__init(&msg->q1sol)) {
    lab1_interfaces__srv__SetMode_Response__fini(msg);
    return false;
  }
  // q2sol
  if (!std_msgs__msg__Float64__init(&msg->q2sol)) {
    lab1_interfaces__srv__SetMode_Response__fini(msg);
    return false;
  }
  // ranx
  if (!std_msgs__msg__Float64__init(&msg->ranx)) {
    lab1_interfaces__srv__SetMode_Response__fini(msg);
    return false;
  }
  // rany
  if (!std_msgs__msg__Float64__init(&msg->rany)) {
    lab1_interfaces__srv__SetMode_Response__fini(msg);
    return false;
  }
  // ranz
  if (!std_msgs__msg__Float64__init(&msg->ranz)) {
    lab1_interfaces__srv__SetMode_Response__fini(msg);
    return false;
  }
  return true;
}

void
lab1_interfaces__srv__SetMode_Response__fini(lab1_interfaces__srv__SetMode_Response * msg)
{
  if (!msg) {
    return;
  }
  // result
  std_msgs__msg__UInt8__fini(&msg->result);
  // ipk
  std_msgs__msg__UInt8__fini(&msg->ipk);
  // q0sol
  std_msgs__msg__Float64__fini(&msg->q0sol);
  // q1sol
  std_msgs__msg__Float64__fini(&msg->q1sol);
  // q2sol
  std_msgs__msg__Float64__fini(&msg->q2sol);
  // ranx
  std_msgs__msg__Float64__fini(&msg->ranx);
  // rany
  std_msgs__msg__Float64__fini(&msg->rany);
  // ranz
  std_msgs__msg__Float64__fini(&msg->ranz);
}

bool
lab1_interfaces__srv__SetMode_Response__are_equal(const lab1_interfaces__srv__SetMode_Response * lhs, const lab1_interfaces__srv__SetMode_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // result
  if (!std_msgs__msg__UInt8__are_equal(
      &(lhs->result), &(rhs->result)))
  {
    return false;
  }
  // ipk
  if (!std_msgs__msg__UInt8__are_equal(
      &(lhs->ipk), &(rhs->ipk)))
  {
    return false;
  }
  // q0sol
  if (!std_msgs__msg__Float64__are_equal(
      &(lhs->q0sol), &(rhs->q0sol)))
  {
    return false;
  }
  // q1sol
  if (!std_msgs__msg__Float64__are_equal(
      &(lhs->q1sol), &(rhs->q1sol)))
  {
    return false;
  }
  // q2sol
  if (!std_msgs__msg__Float64__are_equal(
      &(lhs->q2sol), &(rhs->q2sol)))
  {
    return false;
  }
  // ranx
  if (!std_msgs__msg__Float64__are_equal(
      &(lhs->ranx), &(rhs->ranx)))
  {
    return false;
  }
  // rany
  if (!std_msgs__msg__Float64__are_equal(
      &(lhs->rany), &(rhs->rany)))
  {
    return false;
  }
  // ranz
  if (!std_msgs__msg__Float64__are_equal(
      &(lhs->ranz), &(rhs->ranz)))
  {
    return false;
  }
  return true;
}

bool
lab1_interfaces__srv__SetMode_Response__copy(
  const lab1_interfaces__srv__SetMode_Response * input,
  lab1_interfaces__srv__SetMode_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // result
  if (!std_msgs__msg__UInt8__copy(
      &(input->result), &(output->result)))
  {
    return false;
  }
  // ipk
  if (!std_msgs__msg__UInt8__copy(
      &(input->ipk), &(output->ipk)))
  {
    return false;
  }
  // q0sol
  if (!std_msgs__msg__Float64__copy(
      &(input->q0sol), &(output->q0sol)))
  {
    return false;
  }
  // q1sol
  if (!std_msgs__msg__Float64__copy(
      &(input->q1sol), &(output->q1sol)))
  {
    return false;
  }
  // q2sol
  if (!std_msgs__msg__Float64__copy(
      &(input->q2sol), &(output->q2sol)))
  {
    return false;
  }
  // ranx
  if (!std_msgs__msg__Float64__copy(
      &(input->ranx), &(output->ranx)))
  {
    return false;
  }
  // rany
  if (!std_msgs__msg__Float64__copy(
      &(input->rany), &(output->rany)))
  {
    return false;
  }
  // ranz
  if (!std_msgs__msg__Float64__copy(
      &(input->ranz), &(output->ranz)))
  {
    return false;
  }
  return true;
}

lab1_interfaces__srv__SetMode_Response *
lab1_interfaces__srv__SetMode_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  lab1_interfaces__srv__SetMode_Response * msg = (lab1_interfaces__srv__SetMode_Response *)allocator.allocate(sizeof(lab1_interfaces__srv__SetMode_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(lab1_interfaces__srv__SetMode_Response));
  bool success = lab1_interfaces__srv__SetMode_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
lab1_interfaces__srv__SetMode_Response__destroy(lab1_interfaces__srv__SetMode_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    lab1_interfaces__srv__SetMode_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
lab1_interfaces__srv__SetMode_Response__Sequence__init(lab1_interfaces__srv__SetMode_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  lab1_interfaces__srv__SetMode_Response * data = NULL;

  if (size) {
    data = (lab1_interfaces__srv__SetMode_Response *)allocator.zero_allocate(size, sizeof(lab1_interfaces__srv__SetMode_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = lab1_interfaces__srv__SetMode_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        lab1_interfaces__srv__SetMode_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
lab1_interfaces__srv__SetMode_Response__Sequence__fini(lab1_interfaces__srv__SetMode_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      lab1_interfaces__srv__SetMode_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

lab1_interfaces__srv__SetMode_Response__Sequence *
lab1_interfaces__srv__SetMode_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  lab1_interfaces__srv__SetMode_Response__Sequence * array = (lab1_interfaces__srv__SetMode_Response__Sequence *)allocator.allocate(sizeof(lab1_interfaces__srv__SetMode_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = lab1_interfaces__srv__SetMode_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
lab1_interfaces__srv__SetMode_Response__Sequence__destroy(lab1_interfaces__srv__SetMode_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    lab1_interfaces__srv__SetMode_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
lab1_interfaces__srv__SetMode_Response__Sequence__are_equal(const lab1_interfaces__srv__SetMode_Response__Sequence * lhs, const lab1_interfaces__srv__SetMode_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!lab1_interfaces__srv__SetMode_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
lab1_interfaces__srv__SetMode_Response__Sequence__copy(
  const lab1_interfaces__srv__SetMode_Response__Sequence * input,
  lab1_interfaces__srv__SetMode_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(lab1_interfaces__srv__SetMode_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    lab1_interfaces__srv__SetMode_Response * data =
      (lab1_interfaces__srv__SetMode_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!lab1_interfaces__srv__SetMode_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          lab1_interfaces__srv__SetMode_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!lab1_interfaces__srv__SetMode_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
