// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from lab1_interfaces:srv/SetMode.idl
// generated code does not contain a copyright notice

#ifndef LAB1_INTERFACES__SRV__DETAIL__SET_MODE__STRUCT_H_
#define LAB1_INTERFACES__SRV__DETAIL__SET_MODE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'mode'
// Member 'newtarget'
#include "std_msgs/msg/detail/u_int8__struct.h"
// Member 'x'
// Member 'y'
// Member 'z'
#include "std_msgs/msg/detail/float64__struct.h"

/// Struct defined in srv/SetMode in the package lab1_interfaces.
typedef struct lab1_interfaces__srv__SetMode_Request
{
  std_msgs__msg__UInt8 mode;
  std_msgs__msg__Float64 x;
  std_msgs__msg__Float64 y;
  std_msgs__msg__Float64 z;
  std_msgs__msg__UInt8 newtarget;
} lab1_interfaces__srv__SetMode_Request;

// Struct for a sequence of lab1_interfaces__srv__SetMode_Request.
typedef struct lab1_interfaces__srv__SetMode_Request__Sequence
{
  lab1_interfaces__srv__SetMode_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} lab1_interfaces__srv__SetMode_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'result'
// Member 'ipk'
// already included above
// #include "std_msgs/msg/detail/u_int8__struct.h"
// Member 'q0sol'
// Member 'q1sol'
// Member 'q2sol'
// Member 'ranx'
// Member 'rany'
// Member 'ranz'
// already included above
// #include "std_msgs/msg/detail/float64__struct.h"

/// Struct defined in srv/SetMode in the package lab1_interfaces.
typedef struct lab1_interfaces__srv__SetMode_Response
{
  std_msgs__msg__UInt8 result;
  std_msgs__msg__UInt8 ipk;
  std_msgs__msg__Float64 q0sol;
  std_msgs__msg__Float64 q1sol;
  std_msgs__msg__Float64 q2sol;
  std_msgs__msg__Float64 ranx;
  std_msgs__msg__Float64 rany;
  std_msgs__msg__Float64 ranz;
} lab1_interfaces__srv__SetMode_Response;

// Struct for a sequence of lab1_interfaces__srv__SetMode_Response.
typedef struct lab1_interfaces__srv__SetMode_Response__Sequence
{
  lab1_interfaces__srv__SetMode_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} lab1_interfaces__srv__SetMode_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // LAB1_INTERFACES__SRV__DETAIL__SET_MODE__STRUCT_H_
