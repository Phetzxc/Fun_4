// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from lab1_interfaces:srv/SetMode.idl
// generated code does not contain a copyright notice

#ifndef LAB1_INTERFACES__SRV__DETAIL__SET_MODE__TRAITS_HPP_
#define LAB1_INTERFACES__SRV__DETAIL__SET_MODE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "lab1_interfaces/srv/detail/set_mode__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'mode'
// Member 'newtarget'
#include "std_msgs/msg/detail/u_int8__traits.hpp"
// Member 'x'
// Member 'y'
// Member 'z'
#include "std_msgs/msg/detail/float64__traits.hpp"

namespace lab1_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const SetMode_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: mode
  {
    out << "mode: ";
    to_flow_style_yaml(msg.mode, out);
    out << ", ";
  }

  // member: x
  {
    out << "x: ";
    to_flow_style_yaml(msg.x, out);
    out << ", ";
  }

  // member: y
  {
    out << "y: ";
    to_flow_style_yaml(msg.y, out);
    out << ", ";
  }

  // member: z
  {
    out << "z: ";
    to_flow_style_yaml(msg.z, out);
    out << ", ";
  }

  // member: newtarget
  {
    out << "newtarget: ";
    to_flow_style_yaml(msg.newtarget, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SetMode_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mode:\n";
    to_block_style_yaml(msg.mode, out, indentation + 2);
  }

  // member: x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x:\n";
    to_block_style_yaml(msg.x, out, indentation + 2);
  }

  // member: y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "y:\n";
    to_block_style_yaml(msg.y, out, indentation + 2);
  }

  // member: z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "z:\n";
    to_block_style_yaml(msg.z, out, indentation + 2);
  }

  // member: newtarget
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "newtarget:\n";
    to_block_style_yaml(msg.newtarget, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SetMode_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace lab1_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use lab1_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const lab1_interfaces::srv::SetMode_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  lab1_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use lab1_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const lab1_interfaces::srv::SetMode_Request & msg)
{
  return lab1_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<lab1_interfaces::srv::SetMode_Request>()
{
  return "lab1_interfaces::srv::SetMode_Request";
}

template<>
inline const char * name<lab1_interfaces::srv::SetMode_Request>()
{
  return "lab1_interfaces/srv/SetMode_Request";
}

template<>
struct has_fixed_size<lab1_interfaces::srv::SetMode_Request>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Float64>::value && has_fixed_size<std_msgs::msg::UInt8>::value> {};

template<>
struct has_bounded_size<lab1_interfaces::srv::SetMode_Request>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Float64>::value && has_bounded_size<std_msgs::msg::UInt8>::value> {};

template<>
struct is_message<lab1_interfaces::srv::SetMode_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'result'
// Member 'ipk'
// already included above
// #include "std_msgs/msg/detail/u_int8__traits.hpp"
// Member 'q0sol'
// Member 'q1sol'
// Member 'q2sol'
// Member 'ranx'
// Member 'rany'
// Member 'ranz'
// already included above
// #include "std_msgs/msg/detail/float64__traits.hpp"

namespace lab1_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const SetMode_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: result
  {
    out << "result: ";
    to_flow_style_yaml(msg.result, out);
    out << ", ";
  }

  // member: ipk
  {
    out << "ipk: ";
    to_flow_style_yaml(msg.ipk, out);
    out << ", ";
  }

  // member: q0sol
  {
    out << "q0sol: ";
    to_flow_style_yaml(msg.q0sol, out);
    out << ", ";
  }

  // member: q1sol
  {
    out << "q1sol: ";
    to_flow_style_yaml(msg.q1sol, out);
    out << ", ";
  }

  // member: q2sol
  {
    out << "q2sol: ";
    to_flow_style_yaml(msg.q2sol, out);
    out << ", ";
  }

  // member: ranx
  {
    out << "ranx: ";
    to_flow_style_yaml(msg.ranx, out);
    out << ", ";
  }

  // member: rany
  {
    out << "rany: ";
    to_flow_style_yaml(msg.rany, out);
    out << ", ";
  }

  // member: ranz
  {
    out << "ranz: ";
    to_flow_style_yaml(msg.ranz, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SetMode_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: result
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "result:\n";
    to_block_style_yaml(msg.result, out, indentation + 2);
  }

  // member: ipk
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ipk:\n";
    to_block_style_yaml(msg.ipk, out, indentation + 2);
  }

  // member: q0sol
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "q0sol:\n";
    to_block_style_yaml(msg.q0sol, out, indentation + 2);
  }

  // member: q1sol
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "q1sol:\n";
    to_block_style_yaml(msg.q1sol, out, indentation + 2);
  }

  // member: q2sol
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "q2sol:\n";
    to_block_style_yaml(msg.q2sol, out, indentation + 2);
  }

  // member: ranx
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ranx:\n";
    to_block_style_yaml(msg.ranx, out, indentation + 2);
  }

  // member: rany
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rany:\n";
    to_block_style_yaml(msg.rany, out, indentation + 2);
  }

  // member: ranz
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ranz:\n";
    to_block_style_yaml(msg.ranz, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SetMode_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace lab1_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use lab1_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const lab1_interfaces::srv::SetMode_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  lab1_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use lab1_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const lab1_interfaces::srv::SetMode_Response & msg)
{
  return lab1_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<lab1_interfaces::srv::SetMode_Response>()
{
  return "lab1_interfaces::srv::SetMode_Response";
}

template<>
inline const char * name<lab1_interfaces::srv::SetMode_Response>()
{
  return "lab1_interfaces/srv/SetMode_Response";
}

template<>
struct has_fixed_size<lab1_interfaces::srv::SetMode_Response>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Float64>::value && has_fixed_size<std_msgs::msg::UInt8>::value> {};

template<>
struct has_bounded_size<lab1_interfaces::srv::SetMode_Response>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Float64>::value && has_bounded_size<std_msgs::msg::UInt8>::value> {};

template<>
struct is_message<lab1_interfaces::srv::SetMode_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<lab1_interfaces::srv::SetMode>()
{
  return "lab1_interfaces::srv::SetMode";
}

template<>
inline const char * name<lab1_interfaces::srv::SetMode>()
{
  return "lab1_interfaces/srv/SetMode";
}

template<>
struct has_fixed_size<lab1_interfaces::srv::SetMode>
  : std::integral_constant<
    bool,
    has_fixed_size<lab1_interfaces::srv::SetMode_Request>::value &&
    has_fixed_size<lab1_interfaces::srv::SetMode_Response>::value
  >
{
};

template<>
struct has_bounded_size<lab1_interfaces::srv::SetMode>
  : std::integral_constant<
    bool,
    has_bounded_size<lab1_interfaces::srv::SetMode_Request>::value &&
    has_bounded_size<lab1_interfaces::srv::SetMode_Response>::value
  >
{
};

template<>
struct is_service<lab1_interfaces::srv::SetMode>
  : std::true_type
{
};

template<>
struct is_service_request<lab1_interfaces::srv::SetMode_Request>
  : std::true_type
{
};

template<>
struct is_service_response<lab1_interfaces::srv::SetMode_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // LAB1_INTERFACES__SRV__DETAIL__SET_MODE__TRAITS_HPP_
