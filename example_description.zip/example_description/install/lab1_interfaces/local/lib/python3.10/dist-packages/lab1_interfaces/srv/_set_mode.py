# generated from rosidl_generator_py/resource/_idl.py.em
# with input from lab1_interfaces:srv/SetMode.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_SetMode_Request(type):
    """Metaclass of message 'SetMode_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('lab1_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'lab1_interfaces.srv.SetMode_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__set_mode__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__set_mode__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__set_mode__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__set_mode__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__set_mode__request

            from std_msgs.msg import Float64
            if Float64.__class__._TYPE_SUPPORT is None:
                Float64.__class__.__import_type_support__()

            from std_msgs.msg import UInt8
            if UInt8.__class__._TYPE_SUPPORT is None:
                UInt8.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class SetMode_Request(metaclass=Metaclass_SetMode_Request):
    """Message class 'SetMode_Request'."""

    __slots__ = [
        '_mode',
        '_x',
        '_y',
        '_z',
        '_newtarget',
    ]

    _fields_and_field_types = {
        'mode': 'std_msgs/UInt8',
        'x': 'std_msgs/Float64',
        'y': 'std_msgs/Float64',
        'z': 'std_msgs/Float64',
        'newtarget': 'std_msgs/UInt8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'UInt8'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Float64'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Float64'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Float64'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'UInt8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from std_msgs.msg import UInt8
        self.mode = kwargs.get('mode', UInt8())
        from std_msgs.msg import Float64
        self.x = kwargs.get('x', Float64())
        from std_msgs.msg import Float64
        self.y = kwargs.get('y', Float64())
        from std_msgs.msg import Float64
        self.z = kwargs.get('z', Float64())
        from std_msgs.msg import UInt8
        self.newtarget = kwargs.get('newtarget', UInt8())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.mode != other.mode:
            return False
        if self.x != other.x:
            return False
        if self.y != other.y:
            return False
        if self.z != other.z:
            return False
        if self.newtarget != other.newtarget:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def mode(self):
        """Message field 'mode'."""
        return self._mode

    @mode.setter
    def mode(self, value):
        if __debug__:
            from std_msgs.msg import UInt8
            assert \
                isinstance(value, UInt8), \
                "The 'mode' field must be a sub message of type 'UInt8'"
        self._mode = value

    @builtins.property
    def x(self):
        """Message field 'x'."""
        return self._x

    @x.setter
    def x(self, value):
        if __debug__:
            from std_msgs.msg import Float64
            assert \
                isinstance(value, Float64), \
                "The 'x' field must be a sub message of type 'Float64'"
        self._x = value

    @builtins.property
    def y(self):
        """Message field 'y'."""
        return self._y

    @y.setter
    def y(self, value):
        if __debug__:
            from std_msgs.msg import Float64
            assert \
                isinstance(value, Float64), \
                "The 'y' field must be a sub message of type 'Float64'"
        self._y = value

    @builtins.property
    def z(self):
        """Message field 'z'."""
        return self._z

    @z.setter
    def z(self, value):
        if __debug__:
            from std_msgs.msg import Float64
            assert \
                isinstance(value, Float64), \
                "The 'z' field must be a sub message of type 'Float64'"
        self._z = value

    @builtins.property
    def newtarget(self):
        """Message field 'newtarget'."""
        return self._newtarget

    @newtarget.setter
    def newtarget(self, value):
        if __debug__:
            from std_msgs.msg import UInt8
            assert \
                isinstance(value, UInt8), \
                "The 'newtarget' field must be a sub message of type 'UInt8'"
        self._newtarget = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_SetMode_Response(type):
    """Metaclass of message 'SetMode_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('lab1_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'lab1_interfaces.srv.SetMode_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__set_mode__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__set_mode__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__set_mode__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__set_mode__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__set_mode__response

            from std_msgs.msg import Float64
            if Float64.__class__._TYPE_SUPPORT is None:
                Float64.__class__.__import_type_support__()

            from std_msgs.msg import UInt8
            if UInt8.__class__._TYPE_SUPPORT is None:
                UInt8.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class SetMode_Response(metaclass=Metaclass_SetMode_Response):
    """Message class 'SetMode_Response'."""

    __slots__ = [
        '_result',
        '_ipk',
        '_q0sol',
        '_q1sol',
        '_q2sol',
        '_ranx',
        '_rany',
        '_ranz',
    ]

    _fields_and_field_types = {
        'result': 'std_msgs/UInt8',
        'ipk': 'std_msgs/UInt8',
        'q0sol': 'std_msgs/Float64',
        'q1sol': 'std_msgs/Float64',
        'q2sol': 'std_msgs/Float64',
        'ranx': 'std_msgs/Float64',
        'rany': 'std_msgs/Float64',
        'ranz': 'std_msgs/Float64',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'UInt8'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'UInt8'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Float64'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Float64'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Float64'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Float64'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Float64'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Float64'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from std_msgs.msg import UInt8
        self.result = kwargs.get('result', UInt8())
        from std_msgs.msg import UInt8
        self.ipk = kwargs.get('ipk', UInt8())
        from std_msgs.msg import Float64
        self.q0sol = kwargs.get('q0sol', Float64())
        from std_msgs.msg import Float64
        self.q1sol = kwargs.get('q1sol', Float64())
        from std_msgs.msg import Float64
        self.q2sol = kwargs.get('q2sol', Float64())
        from std_msgs.msg import Float64
        self.ranx = kwargs.get('ranx', Float64())
        from std_msgs.msg import Float64
        self.rany = kwargs.get('rany', Float64())
        from std_msgs.msg import Float64
        self.ranz = kwargs.get('ranz', Float64())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.result != other.result:
            return False
        if self.ipk != other.ipk:
            return False
        if self.q0sol != other.q0sol:
            return False
        if self.q1sol != other.q1sol:
            return False
        if self.q2sol != other.q2sol:
            return False
        if self.ranx != other.ranx:
            return False
        if self.rany != other.rany:
            return False
        if self.ranz != other.ranz:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def result(self):
        """Message field 'result'."""
        return self._result

    @result.setter
    def result(self, value):
        if __debug__:
            from std_msgs.msg import UInt8
            assert \
                isinstance(value, UInt8), \
                "The 'result' field must be a sub message of type 'UInt8'"
        self._result = value

    @builtins.property
    def ipk(self):
        """Message field 'ipk'."""
        return self._ipk

    @ipk.setter
    def ipk(self, value):
        if __debug__:
            from std_msgs.msg import UInt8
            assert \
                isinstance(value, UInt8), \
                "The 'ipk' field must be a sub message of type 'UInt8'"
        self._ipk = value

    @builtins.property
    def q0sol(self):
        """Message field 'q0sol'."""
        return self._q0sol

    @q0sol.setter
    def q0sol(self, value):
        if __debug__:
            from std_msgs.msg import Float64
            assert \
                isinstance(value, Float64), \
                "The 'q0sol' field must be a sub message of type 'Float64'"
        self._q0sol = value

    @builtins.property
    def q1sol(self):
        """Message field 'q1sol'."""
        return self._q1sol

    @q1sol.setter
    def q1sol(self, value):
        if __debug__:
            from std_msgs.msg import Float64
            assert \
                isinstance(value, Float64), \
                "The 'q1sol' field must be a sub message of type 'Float64'"
        self._q1sol = value

    @builtins.property
    def q2sol(self):
        """Message field 'q2sol'."""
        return self._q2sol

    @q2sol.setter
    def q2sol(self, value):
        if __debug__:
            from std_msgs.msg import Float64
            assert \
                isinstance(value, Float64), \
                "The 'q2sol' field must be a sub message of type 'Float64'"
        self._q2sol = value

    @builtins.property
    def ranx(self):
        """Message field 'ranx'."""
        return self._ranx

    @ranx.setter
    def ranx(self, value):
        if __debug__:
            from std_msgs.msg import Float64
            assert \
                isinstance(value, Float64), \
                "The 'ranx' field must be a sub message of type 'Float64'"
        self._ranx = value

    @builtins.property
    def rany(self):
        """Message field 'rany'."""
        return self._rany

    @rany.setter
    def rany(self, value):
        if __debug__:
            from std_msgs.msg import Float64
            assert \
                isinstance(value, Float64), \
                "The 'rany' field must be a sub message of type 'Float64'"
        self._rany = value

    @builtins.property
    def ranz(self):
        """Message field 'ranz'."""
        return self._ranz

    @ranz.setter
    def ranz(self, value):
        if __debug__:
            from std_msgs.msg import Float64
            assert \
                isinstance(value, Float64), \
                "The 'ranz' field must be a sub message of type 'Float64'"
        self._ranz = value


class Metaclass_SetMode(type):
    """Metaclass of service 'SetMode'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('lab1_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'lab1_interfaces.srv.SetMode')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__set_mode

            from lab1_interfaces.srv import _set_mode
            if _set_mode.Metaclass_SetMode_Request._TYPE_SUPPORT is None:
                _set_mode.Metaclass_SetMode_Request.__import_type_support__()
            if _set_mode.Metaclass_SetMode_Response._TYPE_SUPPORT is None:
                _set_mode.Metaclass_SetMode_Response.__import_type_support__()


class SetMode(metaclass=Metaclass_SetMode):
    from lab1_interfaces.srv._set_mode import SetMode_Request as Request
    from lab1_interfaces.srv._set_mode import SetMode_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
